FLOORBALL TACTICS STUDIO V6 – PWA

PUBLICERA PÅ GITHUB PAGES
1. Skapa ett repository på GitHub, t.ex. innebandy-taktik.
2. Ladda upp ALLA filer i denna mapp till repositoryts rot:
   index.html
   manifest.webmanifest
   sw.js
   icon-192.png
   icon-512.png
3. Settings > Pages > Deploy from a branch.
4. Välj main och /(root), sedan Save.
5. Öppna GitHub Pages-adressen på surfplattan.

INSTALLATION
Android/Chrome: välj Installera app eller Lägg till på startskärmen.
iPad/Safari: Dela > Lägg till på hemskärmen.

Offlinefunktionen aktiveras efter att appen har öppnats online minst en gång.
